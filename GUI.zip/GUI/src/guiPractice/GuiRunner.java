package guiPractice;

public class GuiRunner{
	public static void main(String args[]){
		guibondbond gui = new guibondbond();
		gui.setVisible(true);
	}
}