package guiPractice;

import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.Objects;

import delaunay_triangulation.*;
import GUI.*;
import Test.*;

public class Gui2 extends JFrame implements ActionListener{
	
	private JButton button1;
	private JButton button2;
	private JButton mash;
	private JButton next;
	private JButton previous;
	private JButton morphImages;
	private ImageIcon faceSketch;	
	private ImageIcon icon;
	private JLabel imageLabel;
	private JLabel imageLabel2;
	private JLabel imageLabel3;
	private JLabel instructions;
	private JSlider slider;
	private String contentType;
	private Image firstFace;
	private Image secondFace;
	private Image newimg2;
	private Image newimg3;
	private JPanel boarder;
	private int firstSelected;
	private int secondSelected;
	private int meshSelected;
	private int numberStep;
	private int save1X;
	private int save1Y;
	private int save2X;
	private int save2Y;
	private boolean image1pressed;
	private boolean image2pressed;
	private int [] record1X;
	private int [] record1Y;
	private int [] record2X;
	private int [] record2Y;
	private String[] instructionWords;
	private Color[] colors;
	private Boolean[] hasBeenTraversed;
	private Boolean[] has1BeenModified;
	private Boolean[] has2BeenModified;
	private int highestTraverse;
	
	public Gui2(){
		getContentPane().setLayout(null);
		setSize(600, 500);
		getContentPane().setBackground(new Color(51, 102, 153));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		button1 = new JButton("Click me");
		button2 = new JButton("Click me");
		button1.setBounds(50, 200, 100, 30);
		button2.setBounds(450, 200, 100, 30);
		button1.addActionListener(this);
		button2.addActionListener(this);
		getContentPane().add(button1);
		getContentPane().add(button2);
		
		faceSketch = new ImageIcon(getClass().getResource("faceSketch.jpg"));
		Image image = faceSketch.getImage(); 
		Image newimg = image.getScaledInstance(120, 150,  java.awt.Image.SCALE_SMOOTH);  
		faceSketch = new ImageIcon(newimg);
		
		imageLabel = new JLabel(faceSketch);
		imageLabel.setBounds(240, 5, 120, 150);
		getContentPane().add(imageLabel);	
		
		slider = new JSlider(JSlider.HORIZONTAL, 0, 1, 0);
		slider.setMajorTickSpacing((int) 0.5);
		slider.setMinorTickSpacing((int) 0.1);
		slider.setBounds(175, 210, 250, 10);
		getContentPane().add(slider);
		
		instructions = new JLabel();
		instructions.setBounds(165, 170, 280, 20);
		getContentPane().add(instructions);
		
		boarder = new JPanel();
		boarder.setBounds(160, 170, 280, 20);
		getContentPane().add(boarder);
		
		mash = new JButton("Begin!");
		mash.setBounds(80, 20, 120, 40);
		getContentPane().add(mash);
		mash.addActionListener(this);
		mash.setVisible(false);
		
		next = new JButton("Next");
		next.setBounds(400, 60, 120, 80);
		getContentPane().add(next);
		next.addActionListener(this);
		next.setVisible(false);
		
		previous = new JButton("Previous");
		previous.setBounds(80, 60, 120, 80);
		getContentPane().add(previous);
		previous.addActionListener(this);
		previous.setVisible(false);
		
		morphImages = new JButton("Morph Images");
		morphImages.setBounds(235, 300 , 140, 40);
		getContentPane().add(morphImages);
		morphImages.addActionListener(this);
		morphImages.setVisible(false);
		
		firstSelected = 0;
		secondSelected = 0;
		meshSelected = 0;
		
		save1X = 0;
		save1Y = 0;
		save2X = 0;
		save2Y = 0;
		
		image1pressed = false;
		image2pressed = false;
		
	    record1X = new int[30];
	    record1Y = new int[30];
	    record2X = new int[30];
	    record2Y = new int[30];
	    instructionWords = new String[20];
	    colors = new Color[30];
	    hasBeenTraversed = new Boolean[30];
	    for (int i = 0; i < 30; i++){
	    	hasBeenTraversed[i] = false;
	    }
	    has1BeenModified = new Boolean[30];
	    for (int i = 0; i < 30; i++){
	    	has1BeenModified[i] = false;
	    }
	    has2BeenModified = new Boolean[30];
	    for (int i = 0; i < 30; i++){
	    	has2BeenModified[i] = false;
	    }
	    
	    highestTraverse = 0;
	    
	    instructionWords[0] = "Select right eye";
	    instructionWords[1] = "select chin";
	    instructionWords[2] = "sdlkfjslkdjfsldkfjsld";
	    instructionWords[3] = "dfdfdfdfdfdfdfdfsssssss";
	    instructionWords[4] = "sdlkfjslkdjfsldkfjsld";
	    instructionWords[5] = "dfdfdfdfdfdfdfdfsssssss";
	    instructionWords[6] = "sdlkfjslkdjfsldkfjsld";
	    instructionWords[7] = "dfdfdfdfdfdfdfdfsssssss";	    
	    instructionWords[8] = "sdlkfjslkdjfsldkfjsld";
	    instructionWords[9] = "dfdfdfdfdfdfdfdfsssssss";	    
	    instructionWords[10] = "sdlkfjslkdjfsldkfjsld";
	    instructionWords[11] = "dfdfdfdfdfdfdfdfsssssss";
	    instructionWords[12] = "sdlkfjslkdjfsldkfjsld";
	    instructionWords[13] = "dfdfdfdfdfdfdfdfsssssss";	       
	    
	    Color alternateGreen = new Color(83, 221, 89);
	    Color alternatePurple = new Color(177, 88, 255);
	    Color alternateYellow = new Color(177, 207, 0);
	    Color alternateOrange = new Color(255, 173, 65);
	    
	    colors[0] = Color.RED;
	    colors[1] = Color.CYAN;
	    colors[2] = Color.GREEN;
	    colors[3] = alternateYellow;
	    colors[4] = Color.MAGENTA;
	    colors[5] = alternateOrange;
	    colors[6] = Color.BLACK;
	    colors[7] = Color.PINK;
	    colors[8] = Color.BLUE;
	    colors[9] = alternateGreen;	    
	    colors[10] = Color.YELLOW;
	    colors[11] = alternatePurple;
	    colors[12] = Color.ORANGE;
	    colors[13] = Color.GRAY;
	    
	    JButton[] framy = new JButton[90];
	    for (int i = 0; i<80; i++){
	    	framy[i] = new JButton();
	    	framy[i].setBounds(5*i, 10, 5, 5);
	    	getContentPane().add(framy[i]);
	    }
	}
	
	public void paintComponent(Graphics graphics){
		super.paintComponents(graphics);
		for (int i = 0; i < highestTraverse; i++){
			if(i != numberStep){
				graphics.setColor(colors[i]);
				graphics.fillOval(record1X[i], record1Y[i], 6, 6);					
				graphics.fillOval(record2X[i], record2Y[i], 6, 6);
			}
		}				
		if (has1BeenModified[numberStep] == true){
			graphics.setColor(colors[numberStep]);										
			graphics.fillOval(save1X, save1Y, 6, 6);
		}
		else{
			graphics.setColor(colors[numberStep]);
			graphics.fillOval(record1X[numberStep], record1Y[numberStep], 6, 6);				
		}
		if (has2BeenModified[numberStep] == true){
			graphics.setColor(colors[numberStep]);										
			graphics.fillOval(save2X, save2Y, 6, 6);
		}
		else{
			graphics.setColor(colors[numberStep]);
			graphics.fillOval(record2X[numberStep], record2Y[numberStep], 6, 6);				
		}
			graphics.dispose();
	}
	
	
	public void actionPerformed(ActionEvent e){
		if (e.getSource() == button1){
			if (meshSelected == 0){
				JFileChooser chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				File file = chooser.getSelectedFile();
				Path filePath = Paths.get(file.getAbsolutePath());
				try {
					contentType = Files.probeContentType(filePath);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				if (Objects.equals("image/jpeg", contentType)){
		    	
					icon = new ImageIcon(filePath.toString());
					firstFace = icon.getImage(); 
					newimg2 = firstFace.getScaledInstance(120, 150,  java.awt.Image.SCALE_SMOOTH);  
					icon = new ImageIcon(newimg2);
					imageLabel2 = new JLabel(icon);
					imageLabel2.setBounds(50, 240, 120, 150);
					getContentPane().add(imageLabel2);
					firstSelected = 1;
				
					if (secondSelected == 1){
						mash.setVisible(true);	
					}
				
					imageLabel2.addMouseListener(new MouseAdapter() { 
						public void mousePressed(MouseEvent me) { 
							if (meshSelected == 1){
								Graphics graphics = getGraphics();
								save1X = me.getX()+56;
								save1Y = me.getY()+268;								
								has1BeenModified[numberStep] = true;
								paintComponent(graphics);
								image1pressed = true;
								if (image1pressed == true && image2pressed == true){
									if (numberStep != 13){
										next.setVisible(true);
									}
									else{
										morphImages.setVisible(true);
									}
								}
							}
						} 
					});
					repaint();
				}
			}
		}
		else if (e.getSource() == button2){
			if (meshSelected ==0){
				JFileChooser chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				File file = chooser.getSelectedFile();
				Path filePath = Paths.get(file.getAbsolutePath());
				try {
					contentType = Files.probeContentType(filePath);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				if (Objects.equals("image/jpeg", contentType)){
		    	
					icon = new ImageIcon(filePath.toString());
					secondFace = icon.getImage(); 
					newimg3 = secondFace.getScaledInstance(120, 150,  java.awt.Image.SCALE_SMOOTH);  
					icon = new ImageIcon(newimg3);
					imageLabel3 = new JLabel(icon);
					imageLabel3.setBounds(450, 240, 120, 150);
					getContentPane().add(imageLabel3);
					secondSelected = 1;
				
					if (firstSelected == 1){
						mash.setVisible(true);
					}
				
					imageLabel3.addMouseListener(new MouseAdapter() { 
						public void mousePressed(MouseEvent me) { 
							if (meshSelected == 1){
								Graphics graphics = getGraphics();
								save2X = me.getX()+456;
								save2Y = me.getY()+268;								
								has2BeenModified[numberStep] = true;
								paintComponent(graphics);
								image2pressed = true;
								if (image1pressed == true && image2pressed == true){
									if (numberStep != 13){
										next.setVisible(true);
									}
									else{
										morphImages.setVisible(true);
									}
								}
							}
						} 
					});
					repaint();
				}
		    }
		}
		else if (e.getSource() == mash){
			meshSelected = 1;
			numberStep = 0;
			instructions.setText(instructionWords[numberStep]);
		}
		else if (e.getSource() == next){
			previous.setVisible(true);
			if (has1BeenModified[numberStep] == true){
				record1X[numberStep] = save1X;
				record1Y[numberStep] = save1Y;
			}
			if (has2BeenModified[numberStep] == true){
				record2X[numberStep] = save2X;
				record2Y[numberStep] = save2Y;	
			}
			if (hasBeenTraversed[numberStep] == false){
				next.setVisible(false);
				highestTraverse = numberStep+1;
			}
			has1BeenModified[numberStep] = false;
			has2BeenModified[numberStep] = false;
			hasBeenTraversed[numberStep] = true;
			numberStep = numberStep+1;
		    instructions.setText(instructionWords[numberStep]);
		    image1pressed = false;
		    image2pressed = false;
		    save1X = 0;
		    save1Y = 0;
		    save2X = 0;
		    save2Y = 0;
		}
		else if (e.getSource() == previous){
			next.setVisible(true);

			if (has1BeenModified[numberStep] == true){
				record1X[numberStep] = save1X;
				record1Y[numberStep] = save1Y;
			}
			if (has2BeenModified[numberStep] == true){
				record2X[numberStep] = save2X;
				record2Y[numberStep] = save2Y;	
			}
			has1BeenModified[numberStep] = false;
			has2BeenModified[numberStep] = false;
			numberStep = numberStep - 1;
		    instructions.setText(instructionWords[numberStep]);
		    save1X = 0;
		    save1Y = 0;
		    save2X = 0;
		    save2Y = 0;			
		    if (numberStep == 0){
				previous.setVisible(false);
			}
		}
		else if (e.getSource() == morphImages){
			Delaunay_Triangulation dt1 = new Delaunay_Triangulation();
			Delaunay_Triangulation dt2 = new Delaunay_Triangulation();			
			for (int i = 0; i < numberStep; i++){
				dt1.insertPoint(new Point_dt(record1X[i], record1Y[i]));
				dt2.insertPoint(new Point_dt(record2X[i], record2Y[i]));				
			}

			Iterator<Triangle_dt> iterator1 = dt1.trianglesIterator();

			while (iterator1.hasNext()) {
				Triangle_dt curr1 = iterator1.next();
				if (!curr1.isHalfplane()) {
					System.out.println(curr1.p1() + ", " + curr1.p2() + ", "
							+ curr1.p3());
				}
			}
			
			Iterator<Triangle_dt> iterator2 = dt2.trianglesIterator();

			while (iterator2.hasNext()) {
				Triangle_dt curr2 = iterator2.next();
				if (!curr2.isHalfplane()) {
					System.out.println(curr2.p1() + ", " + curr2.p2() + ", "
							+ curr2.p3());
				}
			}
		}
	}
}

