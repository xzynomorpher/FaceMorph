package guiPractice;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ImageHandle {
	

	public static void main(String args[]){
		Gui2 Gui2 = new Gui2();
		Gui2.setVisible(true);
	}
}